# Plugin Chrome No Block News

### Plugin Chrome para remover Bloqueio de Assinatura em Sites de Notícias Brasileiros

Para ativar, faça o download do projeto em ZIP.

Depois descompacta a pasta do projeto

1. Acesse [chrome://extensions/](chrome://extensions/) no seu chrome
2. Ative no canto direito o Modo Desenvolvedor.
3. Localize do lado esquerdo do chrome, ainda em extensions, a opção 'Carregar expandida' e escolha
o diretorio descompactado do plugin no seu computador.

Pronto, seu plugin já está ativo e funcionando

## Author

* **Fred Portela** - *Senior System Analyst*

## License

[MIT License](http://www.opensource.org/licenses/mit-license.php)
